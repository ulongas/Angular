export interface IHosts {    
    hostId: number;
    name: string;
    state: number;
    processorCount: number;
    physicalMemory: number;
}