export interface IClusters {    
    clusterId: number;
    name: string;
}