export interface IComputerDetails {
    name: string;
    ipAddress: string;
    memory: number;
    user: string;
}