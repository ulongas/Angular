export * from './test2.component';
