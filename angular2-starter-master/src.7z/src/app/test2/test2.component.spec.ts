/* tslint:disable:no-unused-variable */

import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { addProviders, async, inject } from '@angular/core/testing';
import { Test2Component } from './test2.component';

describe('Component: Test2', () => {
  it('should create an instance', () => {
    let component = new Test2Component();
    expect(component).toBeTruthy();
  });
});
