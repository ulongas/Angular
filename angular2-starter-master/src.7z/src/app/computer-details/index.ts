export * from './computer-details.component';
