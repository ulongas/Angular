export * from './welcome-page.component';
