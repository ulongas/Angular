import { Component, OnInit } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'app-welcome-page',
  templateUrl: 'welcome-page.component.html',
  styleUrls: ['welcome-page.component.css']
})
export class WelcomePageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
